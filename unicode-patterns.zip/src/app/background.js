'use strict';

/**!
 * unicode-patterns
 * background.js
 *
 * Ken Frederick
 * ken.frederick@gmx.de
 *
 * http://kennethfrederick.de/
 * http://blog.kennethfrederick.de/
 *
 *
 */


// ------------------------------------------------------------------------
//
// Methods
//
// ------------------------------------------------------------------------
function init(event) {
}

// ------------------------------------------------------------------------
chrome.runtime.onInstalled.addListener(init);
